import React from "react";
import { images } from "../../constants";
import { motion } from "framer-motion";
import "./Header.scss";
import { AppWrap } from '../../wrapper'


// const scaleVariants = {
//   whileInView: {
//     scale: [0, 1],
//     opacity: [0, 1],
//     transition: {
//       duration: 1,
//       ease: "easeInOut",
//     }
//   }
// };

const Header = () => {
  return (
    <div className="app__header app__flex">
      <motion.div
        whileInView={{ x: [-100, 0], opacity: [0, 1] }}
        transition={{ duration: 0.5 }}
        className="app__header-info"
      >
        <div className="app__header-badge">
          <div className="badge-cmp app__flex">
            <span>👋</span>
            <div style={{ marginLeft: 20 }}>
              <p className="p-text">Hello, I am</p>
              <h1 className="head-text">Ojasva Jain</h1>
            </div>
          </div>

          <div className="tag-cmp app__flex">
            <p className="p-text">
              you will get all information about me
            </p>
            {/* <p className="p-text">Web Developer</p> */}
          </div>
        </div>
      </motion.div>

      <motion.div
        whileInView={{ opacity: [0, 1] }}
        transition={{ duration: 0.5, delayChildren: 0.5 }}
        className="app__header-img"
      >
        <img src={images.mainheader} alt="profile" />
        <motion.img
          whileInView={{ scale: [0, 1] }}
          transition={{ duration: 1, ease: "easeInOut" }}
          src={images.circle}
          alt="circle"
          className="overlay_circle"
        />
      </motion.div>

      {/* <motion.div
        variant={scaleVariants}
        whileInView={scaleVariants.whileInView}
        className="app__header-circles"
      >
        {[images.node, images.react, images.redux].map((circle, index) => (
          <div className="circle-cmp app__flex" key={`circle-${index}`}>
            <motion.img
              src={circle}
              alt="circle"
              animate={{ rotate: [0, 360] }}
              transition={{ repeat: Infinity, duration: 2.5 }}
            />
          </div>
        ))}
      </motion.div> */}
    </div>
  );
};

export default AppWrap(Header, "home");
