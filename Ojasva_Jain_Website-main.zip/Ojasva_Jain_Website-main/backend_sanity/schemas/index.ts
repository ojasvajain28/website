
import works from './works'
import testimonials from './testimonials'

import abouts from './abouts'
import experiences from './experiences'
import skills from './skills'
import workExperience from './workExperience'
import contact from './contact'
import profile from './profile'
export const schemaTypes = [abouts, contact, works, testimonials, experiences, skills, workExperience, profile]
